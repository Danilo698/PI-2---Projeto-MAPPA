# Backlog do Produto — MAPPA

> Priorização em MoSCoW (Must, Should, Could, Won't). Cada item está coligado ao(s) [requisito(s)](./requisitos.md) que atende e à [sprint](./cronograma-sprints.md) em que será entregue. A coluna **Issue** deve ser preenchida com o número gerado ao rodar `scripts/create_issues.sh` (ver [instruções](../README.md#issues)).

| Item | História de usuário | Requisitos | Sprint | Prioridade | Issue |
|---|---|---|---|---|---|
| <a id="us01"></a>US01 | Como gestor de mobilidade, quero filtrar acidentes por rodovia e período, para identificar trechos críticos rapidamente. | [RF01](./requisitos.md), RF07 | [Sprint 2](./cronograma-sprints.md#sprint-2) | Must | #TBD |
| <a id="us02"></a>US02 | Como pesquisador, quero visualizar indicadores consolidados de acidentes, feridos e mortos, para embasar minhas análises acadêmicas. | [RF02](./requisitos.md) | [Sprint 2](./cronograma-sprints.md#sprint-2) | Must | #TBD |
| <a id="us03"></a>US03 | Como usuário do sistema, quero que os dados brutos da PRF sejam tratados automaticamente, para trabalhar apenas com informações confiáveis. | [RF06](./requisitos.md), RF08, RF09, RNF05 | [Sprint 1](./cronograma-sprints.md#sprint-1) | Must | #TBD |
| <a id="us04"></a>US04 | Como supervisor de fiscalização, quero ver o ranking de rodovias por número de ocorrências, para direcionar ações preventivas. | [RF04](./requisitos.md) | [Sprint 3](./cronograma-sprints.md#sprint-3) | Should | #TBD |
| <a id="us05"></a>US05 | Como condutor/motorista profissional, quero visualizar as ocorrências em um mapa, para entender a distribuição geográfica dos riscos. | [RF05](./requisitos.md) | [Sprint 3](./cronograma-sprints.md#sprint-3) | Should | #TBD |
| <a id="us06"></a>US06 | Como usuário, quero visualizar gráficos por causa e faixa horária, para identificar padrões de ocorrência. | [RF03](./requisitos.md) | [Sprint 2](./cronograma-sprints.md#sprint-2) | Must | #TBD |
| <a id="us07"></a>US07 | Como gestor, quero combinar múltiplos filtros em uma mesma consulta, para refinar minha análise. | [RF07](./requisitos.md) | [Sprint 3](./cronograma-sprints.md#sprint-3) | Should | #TBD |
| <a id="us08"></a>US08 | Como usuário do dashboard, quero que a aplicação responda rapidamente às minhas interações, para não perder produtividade na análise. | [RNF02](./requisitos.md) | [Sprint 4](./cronograma-sprints.md#sprint-4) | Could | #TBD |
| <a id="us09"></a>US09 | Como novo integrante da equipe, quero um código modularizado e documentado, para dar manutenção e evoluir o sistema com facilidade. | [RNF04](./requisitos.md) | [Sprint 4](./cronograma-sprints.md#sprint-4) | Could | #TBD |

## Legenda de prioridade (MoSCoW)
- **Must** — indispensável para o MVP
- **Should** — importante, mas não bloqueia o MVP
- **Could** — desejável, entra se houver tempo
- **Won't** (não há itens nesta rodada) — fora do escopo atual

---
🔗 Ver também: [Requisitos](./requisitos.md) · [Cronograma em Sprints](./cronograma-sprints.md)
