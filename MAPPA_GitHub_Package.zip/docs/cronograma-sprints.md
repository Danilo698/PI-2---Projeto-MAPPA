# Cronograma em Sprints — MAPPA

> Ajuste as datas conforme o calendário oficial da disciplina. Cada sprint referencia os itens do [Backlog](./backlog.md) que devem ser entregues nela.

## Sprint 1 — Revisão e consolidação da base <a id="sprint-1"></a>
**Período:** Semanas 1–2
**Foco:** Revisão do ETL herdado do PI I; levantamento e validação de requisitos.
**Itens do backlog:** [US03](./backlog.md#us03)
**Entregas:** Requisitos validados (RF/RNF), backlog priorizado, ETL revisado.

## Sprint 2 — Indicadores e gráficos básicos <a id="sprint-2"></a>
**Período:** Semanas 3–4
**Foco:** Implementação dos indicadores consolidados e gráficos básicos do dashboard.
**Itens do backlog:** [US01](./backlog.md#us01), [US02](./backlog.md#us02), [US06](./backlog.md#us06)
**Entregas:** RF01, RF02 e RF03 implementados.

## Sprint 3 — Ranking, mapa e filtros avançados <a id="sprint-3"></a>
**Período:** Semanas 5–6
**Foco:** Implementação do ranking, mapa geográfico e filtros combinados.
**Itens do backlog:** [US04](./backlog.md#us04), [US05](./backlog.md#us05), [US07](./backlog.md#us07)
**Entregas:** RF04, RF05 e RF07 implementados.

## Sprint 4 — Testes, ajustes e manutenibilidade <a id="sprint-4"></a>
**Período:** Semanas 7–8
**Foco:** Testes de usabilidade e desempenho; ajustes de performance; modularização do código.
**Itens do backlog:** [US08](./backlog.md#us08), [US09](./backlog.md#us09)
**Entregas:** RNF01, RNF02 e RNF04 validados; correções de bugs.

## Sprint 5 — Documentação final e apresentação <a id="sprint-5"></a>
**Período:** Semanas 9–10
**Foco:** Consolidação da documentação técnica, revisão geral e preparação da apresentação final.
**Itens do backlog:** —
**Entregas:** Artefato final consolidado, documentação e material de apresentação.

---

```mermaid
gantt
    title Cronograma MAPPA — PI II
    dateFormat  YYYY-MM-DD
    axisFormat  %d/%m
    section Sprints
    Sprint 1 - Base e ETL          :s1, 2026-08-17, 14d
    Sprint 2 - Indicadores         :s2, after s1, 14d
    Sprint 3 - Ranking, mapa       :s3, after s2, 14d
    Sprint 4 - Testes e ajustes    :s4, after s3, 14d
    Sprint 5 - Documentação final  :s5, after s4, 14d
```

---
🔗 Ver também: [Requisitos](./requisitos.md) · [Backlog](./backlog.md)
