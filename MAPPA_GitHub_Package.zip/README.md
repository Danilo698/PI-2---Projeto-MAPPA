# MAPPA — Modelador Analítico de Painéis para Prevenção de Acidentes

Projeto acadêmico desenvolvido na disciplina **Projeto Integrador (PI I e PI II)**, voltado à análise e visualização de dados públicos de acidentes em rodovias federais do Distrito Federal e Entorno (BR-020, 040, 060, 070 e 080), utilizando dados da Polícia Rodoviária Federal (PRF).

## Equipe
João Vitor Velozo · Danilo Lisboa · Igor Cavalcante

## Estrutura do repositório

```
├── docs/                        # Documentação viva do projeto
│   ├── requisitos.md            # Requisitos Funcionais e Não Funcionais
│   ├── backlog.md                # Backlog do produto (histórias + coligações)
│   └── cronograma-sprints.md     # Cronograma em sprints
│
├── entregas/                     # Artefatos formais entregues em cada aula
│   ├── Artefato_1_MAPPA_PI_II.docx
│   ├── Aula03_Artefato2/
│   │   └── Artefato_2_MAPPA_PI_II.docx
│   └── Aula_Apresentacao_Final/
│       └── Apresentacao_MAPPA_Projeto_Final.pptx
│
├── scripts/
│   └── create_issues.sh          # Cria automaticamente as issues do backlog no GitHub
│
└── .github/ISSUE_TEMPLATE/
    └── historia-usuario.md       # Template padrão para novas histórias
```

## Documentação

| Documento | Descrição |
|---|---|
| [Requisitos](./docs/requisitos.md) | Requisitos Funcionais (RF) e Não Funcionais (RNF) |
| [Backlog](./docs/backlog.md) | Histórias de usuário, priorização MoSCoW e coligações com requisitos/sprints |
| [Cronograma em Sprints](./docs/cronograma-sprints.md) | Planejamento de entregas por sprint |

## Issues

O backlog em `docs/backlog.md` foi desenhado para virar issues reais do GitHub, uma por história de usuário, já rotuladas por prioridade e sprint.

Para criar todas de uma vez:

```bash
git clone https://github.com/Danilo698/PI-2---Projeto-MAPPA.git
cd PI-2---Projeto-MAPPA
gh auth login
bash scripts/create_issues.sh
```

Depois, volte em `docs/backlog.md` e substitua os `#TBD` pelos números reais das issues criadas.

## Como contribuir com este pacote

Este conteúdo foi gerado fora do repositório (sem acesso de push automático) e precisa ser adicionado manualmente:

```bash
git clone https://github.com/Danilo698/PI-2---Projeto-MAPPA.git
cd PI-2---Projeto-MAPPA
# copie o conteúdo deste pacote para dentro da pasta clonada, depois:
git add .
git commit -m "docs: adiciona requisitos, backlog, cronograma e entregas do PI II"
git push origin main
```
