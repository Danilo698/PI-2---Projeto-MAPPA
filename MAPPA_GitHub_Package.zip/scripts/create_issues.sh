#!/usr/bin/env bash
# Cria automaticamente uma issue no GitHub para cada história do backlog do MAPPA.
#
# Pré-requisitos:
#   1. Ter o GitHub CLI instalado: https://cli.github.com
#   2. Estar autenticado:  gh auth login
#   3. Rodar este script DENTRO do clone local do repositório:
#        git clone https://github.com/Danilo698/PI-2---Projeto-MAPPA.git
#        cd PI-2---Projeto-MAPPA
#        bash scripts/create_issues.sh
#
# O script cria os labels necessários (caso não existam) e uma issue por
# história de usuário, já com corpo, labels de sprint e prioridade.

set -e

REPO="Danilo698/PI-2---Projeto-MAPPA"

echo "Criando labels (ignora erro se já existirem)..."
gh label create "must"     --color "D93F0B" --repo "$REPO" 2>/dev/null || true
gh label create "should"   --color "FBCA04" --repo "$REPO" 2>/dev/null || true
gh label create "could"    --color "0E8A16" --repo "$REPO" 2>/dev/null || true
gh label create "sprint-1" --color "1D76DB" --repo "$REPO" 2>/dev/null || true
gh label create "sprint-2" --color "1D76DB" --repo "$REPO" 2>/dev/null || true
gh label create "sprint-3" --color "1D76DB" --repo "$REPO" 2>/dev/null || true
gh label create "sprint-4" --color "1D76DB" --repo "$REPO" 2>/dev/null || true
gh label create "backlog"  --color "5319E7" --repo "$REPO" 2>/dev/null || true

create_issue () {
  local title="$1"
  local body="$2"
  local labels="$3"
  echo "Criando issue: $title"
  gh issue create --repo "$REPO" --title "$title" --body "$body" --label "$labels"
}

create_issue "[US01] Filtrar acidentes por rodovia e período" \
"Como gestor de mobilidade, quero filtrar acidentes por rodovia e período, para identificar trechos críticos rapidamente.

**Requisitos:** RF01, RF07
**Sprint:** Sprint 2" \
"backlog,must,sprint-2"

create_issue "[US02] Visualizar indicadores consolidados" \
"Como pesquisador, quero visualizar indicadores consolidados de acidentes, feridos e mortos, para embasar minhas análises acadêmicas.

**Requisitos:** RF02
**Sprint:** Sprint 2" \
"backlog,must,sprint-2"

create_issue "[US03] Tratar automaticamente os dados da PRF (ETL)" \
"Como usuário do sistema, quero que os dados brutos da PRF sejam tratados automaticamente, para trabalhar apenas com informações confiáveis.

**Requisitos:** RF06, RF08, RF09, RNF05
**Sprint:** Sprint 1" \
"backlog,must,sprint-1"

create_issue "[US04] Ranking de rodovias por ocorrências" \
"Como supervisor de fiscalização, quero ver o ranking de rodovias por número de ocorrências, para direcionar ações preventivas.

**Requisitos:** RF04
**Sprint:** Sprint 3" \
"backlog,should,sprint-3"

create_issue "[US05] Mapa geográfico das ocorrências" \
"Como condutor/motorista profissional, quero visualizar as ocorrências em um mapa, para entender a distribuição geográfica dos riscos.

**Requisitos:** RF05
**Sprint:** Sprint 3" \
"backlog,should,sprint-3"

create_issue "[US06] Gráficos por causa e faixa horária" \
"Como usuário, quero visualizar gráficos por causa e faixa horária, para identificar padrões de ocorrência.

**Requisitos:** RF03
**Sprint:** Sprint 2" \
"backlog,must,sprint-2"

create_issue "[US07] Filtros combinados" \
"Como gestor, quero combinar múltiplos filtros em uma mesma consulta, para refinar minha análise.

**Requisitos:** RF07
**Sprint:** Sprint 3" \
"backlog,should,sprint-3"

create_issue "[US08] Desempenho do dashboard" \
"Como usuário do dashboard, quero que a aplicação responda rapidamente às minhas interações, para não perder produtividade na análise.

**Requisitos:** RNF02
**Sprint:** Sprint 4" \
"backlog,could,sprint-4"

create_issue "[US09] Código modularizado e documentado" \
"Como novo integrante da equipe, quero um código modularizado e documentado, para dar manutenção e evoluir o sistema com facilidade.

**Requisitos:** RNF04
**Sprint:** Sprint 4" \
"backlog,could,sprint-4"

echo "Concluído! Copie os números das issues geradas para a coluna 'Issue' em docs/backlog.md."
